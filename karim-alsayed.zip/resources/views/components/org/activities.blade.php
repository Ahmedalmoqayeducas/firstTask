
    <section class="services">
        <div class="container">

            <div class="row">
                <div class="col-md-2 col-lg-3  align-items-stretch" data-aos="fade-up">
                    <div class="icon-box icon-box-pink">
                        <div class="icon"><i class="bx bxl-dribbble"></i></div>
                        <h4 class="title"><a href="">experienced team</a></h4>
                        <p class="description">Cursus ultrices diam</p>
                    </div>
                </div>

                <div class="col-md-2 col-lg-3  align-items-stretch" data-aos="fade-up" data-aos-delay="100">
                    <div class="icon-box icon-box-cyan">
                        <div class="icon"><i class="bx bx-file"></i></div>
                        <h4 class="title"><a href="">Digital Solutions</a></h4>
                        <p class="description">Magna augue temp</p>
                    </div>
                </div>

                <div class="col-md-2 col-lg-3  align-items-stretch  " data-aos="fade-up" data-aos-delay="200">
                    <div class="icon-box icon-box-green">
                        <div class="icon"><i class="bx bx-tachometer"></i></div>
                        <h4 class="title"><a href="">24/7 Support</a></h4>
                        <p class="description">Nunc Quisa volutpat</p>
                    </div>
                </div>

                <div class="col-md-2 col-lg-3  align-items-stretch" data-aos="fade-up" data-aos-delay="200">
                    <div class="icon-box icon-box-blue">
                        <div class="icon"><i class="bx bx-world"></i></div>
                        <h4 class="title"><a href="">Applicable Ideas</a></h4>
                        <p class="description">Cursus ultrices diam</p>
                    </div>
                </div>

            </div>

        </div>
    </section>

