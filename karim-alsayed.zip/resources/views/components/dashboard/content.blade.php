<div class="content-wrapper transition-all duration-150 ltr:ml-[248px] rtl:mr-[248px]" id="content_wrapper">
    <div class="page-content">
        <div class="transition-all duration-150 container-fluid" id="page_layout">
            <div id="content_layout">
                <!-- BEGIN: Breadcrumb -->
                <!-- END: BreadCrumb -->
                <div class=" space-y-5">
                    @yield('content')
                </div>
            </div>
        </div>
    </div>
</div>
