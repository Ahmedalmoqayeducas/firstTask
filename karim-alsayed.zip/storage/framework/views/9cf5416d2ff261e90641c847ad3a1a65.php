<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header">
            <h3 class="card-title"><?php echo e(__('auth.edit_table')); ?></h3>
        </div>
        <!-- /.card-header -->
        <!-- form start -->

        
        <div class="card-text h-full">
            <form class="space-y-4">
                <?php echo csrf_field(); ?>
                
                

                <div class="card-body">
                    <div class="input-area relative">
                        <label for="current-Password" class="form-label"><?php echo e(__('auth.current_password')); ?></label>
                        <div class="relative">
                            <input name="current-password" value="<?php echo e(old('current-password')); ?>" type="password"
                                class="form-control !pl-9" placeholder="Current Password" id="current-password">
                            <iconify-icon icon="heroicons-outline:lock-closed"
                                class="absolute left-2 top-1/2 -translate-y-1/2 text-base text-slate-500"></iconify-icon>
                        </div>
                    </div>
                    <div class="input-area relative">
                        <label for="new-Password" class="form-label"><?php echo e(__('auth.new')); ?></label>
                        <div class="relative">
                            <input name="new-password" value="<?php echo e(old('new-password')); ?>" type="password"
                                class="form-control !pl-9" placeholder="New Password" id="new_password">
                            <iconify-icon icon="heroicons-outline:lock-closed"
                                class="absolute left-2 top-1/2 -translate-y-1/2 text-base text-slate-500"></iconify-icon>
                        </div>
                    </div>

                    <div class="input-area relative">
                        <label for="new-Password-confrimation" class="form-label"><?php echo e(__('auth.confirm')); ?></label>
                        <div class="relative">
                            <input name="new-password-confirmation" value="<?php echo e(old('new-password-confrimation')); ?>"
                                type="password" class="form-control !pl-9" placeholder="New Password Confirmation"
                                id="new_password_confirmation">
                            <iconify-icon icon="heroicons-outline:lock-closed"
                                class="absolute left-2 top-1/2 -translate-y-1/2 text-base text-slate-500"></iconify-icon>
                        </div>
                    </div>

                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                    <button type="button" onclick="updatePassword()" class="btn btn-primary"><?php echo e(__('dashboard.submit')); ?></button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        function updatePassword() {
            return console.log('hello');
            // toastr.success('hello world');
            // axios.patch('<?php echo e(route('password.update')); ?>', {
            //     current_password: document.getElementById('current-password').value,
            //     new_password: document.getElementById('new_password').value,
            //     new_password_confirmation: document.getElementById('new_password_confirmation').value,
            // }).then(function(response) {
            //     toastr.success(response.data.message);
            // }).catch(function(error) {
            //     toastr.error(error.response.data.message);

            // });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\cyberAhmed\Desktop\karim alsayed\resources\views/pages/Auth/edit-password.blade.php ENDPATH**/ ?>