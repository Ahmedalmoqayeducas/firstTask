<?php $__env->startSection('form'); ?>
    <div class="text-center 2xl:mb-10 mb-5">
        <h4 class="font-medium mb-4"><?php echo e(__('auth.forget')); ?></h4>
        <div class="text-slate-500 dark:text-slate-400 text-base">
            <?php echo e(__('auth.reset')); ?>

        </div>
    </div>
    <div
        class="font-normal text-base text-slate-500 dark:text-slate-400 text-center px-2 bg-slate-100 dark:bg-slate-600 rounded
                                py-3 mb-4 mt-10"><?php echo e(__('auth.enter_email')); ?>


    </div>
    <!-- BEGIN: Forgot Password Form -->
    <form class="space-y-4" action='<?php echo e(route('password.change')); ?>' method="POST">
        <?php echo csrf_field(); ?>
        <div class="fromGroup">
            <label class="block capitalize form-label"><?php echo e(__('dashboard.email')); ?></label>
            <div class="relative ">
                <input id="email" type="email" name="email" class="  form-control py-2"
                    placeholder="Enter your Email">
            </div>
        </div>
        <button type="button" onclick="sendResetEmail()" class="btn btn-dark block w-full text-center"><?php echo e(__('auth.send_recovry')); ?></button>
    </form>
    <!-- END: Forgot Password Form -->

    <div class="md:max-w-[345px] mx-auto font-normal text-slate-500 dark:text-slate-400 2xl:mt-12 mt-8 uppercase text-sm">
        <?php echo e(__('auth.back')); ?>

        <a href="<?php echo e(route('auth.show-login', ['guard' => session('guard')])); ?>"
            class="text-slate-900 dark:text-white font-medium hover:underline">
            <?php echo e(__('auth.login')); ?>

        </a>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        function sendResetEmail() {
            axios.post(`forget`, {
                email: document.getElementById('email').value,
            }).then(function(response) {
                toastr.success(response.data.message);
            }).catch(function(error) {
                toastr.error(error.response.data.message);
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\cyberAhmed\Desktop\Admin\resources\views/pages/Auth/forget-password.blade.php ENDPATH**/ ?>