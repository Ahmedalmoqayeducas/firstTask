<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-HELX7GZ5TE"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-HELX7GZ5TE');
</script>
<?php /**PATH D:\karim-alsayed\resources\views/components/analytic.blade.php ENDPATH**/ ?>