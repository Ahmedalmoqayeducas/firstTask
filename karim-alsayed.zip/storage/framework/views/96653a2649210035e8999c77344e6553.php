<?php $__env->startSection('content'); ?>
    
    
    
    <div class="card xl:col-span-2">
        <div class="card-body flex flex-col p-6">
            <header class="flex mb-5 items-center border-b border-slate-100 dark:border-slate-700 pb-5 -mx-6 px-6">
                <div class="flex-1">
                    <div class="card-title text-slate-900 dark:text-white">Multiple Column</div>
                </div>
            </header>
            <div class="card-text h-full ">
                <form class="space-y-4">
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7">
                        <div class="input-area relative">
                            <label for="largeInput" class="form-label">thumbnail</label>
                            <input type="text" class="form-control" placeholder="Full Name">
                        </div>



                        <div class="input-area relative">
                            <label for="largeInput" class="form-label">Company</label>
                            <input type="text" class="form-control" placeholder="Company">
                        </div>
                        <div class="input-area">
                            <label for="select" class="form-label">type of post</label>
                            <select id="select" class="form-control">
                                <option value="option1" class="dark:bg-slate-700">activites post</option>
                                <option value="option1" class="dark:bg-slate-700">News Post</option>
                                <option value="option1" class="dark:bg-slate-700">About Post</option>

                            </select>
                        </div>
                    </div>

                        <!-- /.card-header -->
                       

                    <button class="btn inline-flex justify-center btn-dark">Submit</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        function store() {
            let formData = new FormData();
            formData.append('emp_name', document.getElementById('emp_name').value);
            formData.append('employment_name', document.getElementById('department').value);
            formData.append('email', document.getElementById('email').value);
            formData.append('description', document.getElementById('description').value);
            formData.append('picture', document.getElementById('picture').files[0]);
            formData.append('phone', document.getElementById('phone').value);
            formData.append('facebook', document.getElementById('facebook').value);
            formData.append('linked_in', document.getElementById('linked_in').value);

            axios.post('<?php echo e(route('team.store')); ?>', formData).then(function(response) {
                toastr.success(response.data.message);
                document.getElementById('form').reset();
            }).catch(function(error) {
                toastr.error(error.response.data.message);

            });
        }
    </script>
    <script src="<?php echo e(asset('dashboard/summernote/summernote-bs4.min.js')); ?>"></script>
    <script>
        $(function () {
          // Summernote
          $('#summernote').summernote()

          // CodeMirror
          CodeMirror.fromTextArea(document.getElementById("codeMirrorDemo"), {
            mode: "htmlmixed",
            theme: "monokai"
          });
        })
      </script>
      <script src="<?php echo e(asset('dashboard/dist/js/demo.js')); ?>"></script>
      <script src="<?php echo e(asset('dashboard/dist/js/adminlte.min.js')); ?>"></script>
      <script src="<?php echo e(asset('dashboard/plugins/jquery/jquery.min.js')); ?>"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('dashboard/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>


<link rel="stylesheet" href="<?php echo e(asset('dashboard/summernote/summernote-bs4.min.css')); ?>">
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\cyberAhmed\Desktop\karim alsayed\resources\views/pages/Posts/create.blade.php ENDPATH**/ ?>