<?php $__env->startSection('content'); ?>
    <div class="card">

        <div class="card-body flex flex-col p-6">
            <header class="flex mb-5 items-center border-b border-slate-100 dark:border-slate-700 pb-5 -mx-6 px-6">
                <div class="flex-1">
                    <div class="card-title text-slate-900 dark:text-white"><?php echo e(__('dashboard.create_title')); ?></div>
                </div>
            </header>
            <div class="card-text h-full ">
                <form class="space-y-4" id="form" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="input-area relative">
                        <label for="largeInput" class="form-label"><?php echo e(__('dashboard.create_label')); ?></label>
                        <div class="relative">
                            <input id="name" type="text" class="form-control !pl-9" placeholder="Full Name">
                            <iconify-icon icon="heroicons-outline:user"
                                class="absolute left-2  top-1/2 -translate-y-1/2 text-base text-slate-500"></iconify-icon>
                        </div>
                    </div>
                    <div class="input-area relative">
                        <label for="largeInput" class="form-label"><?php echo e(__('dashboard.email')); ?></label>
                        <div class="relative">
                            <input id="email" type="email" class="form-control !pl-9" placeholder="Your Email">
                            <iconify-icon icon="heroicons-outline:mail"
                                class="absolute left-2 top-1/2 -translate-y-1/2 text-base text-slate-500"></iconify-icon>
                        </div>
                    </div>
                    <div class="input-area relative">
                        <label for="largeInput" class="form-label"><?php echo e(__('dashboard.phone')); ?></label>
                        <div class="relative">
                            <input id="phone" type="tel" class="form-control !pl-9" placeholder="Phone Number"
                                pattern="[0-9]">
                            <iconify-icon icon="heroicons-outline:phone"
                                class="absolute left-2 top-1/2 -translate-y-1/2 text-base text-slate-500"></iconify-icon>
                        </div>
                    </div>
                    <div class="input-area relative">
                        <label for="largeInput" class="form-label"><?php echo e(__('dashboard.password')); ?></label>
                        <div class="relative">
                            <input id="password" type="password" class="form-control !pl-9"
                                placeholder="<?php echo e(__('auth.password_ctr')); ?>">
                            <iconify-icon icon="heroicons-outline:lock-closed"
                                class="absolute left-2 top-1/2 -translate-y-1/2 text-base text-slate-500"></iconify-icon>
                        </div>
                    </div>
                    <input type="file" id="image" name="image">


                    <button type="button" onclick="store()" id="submit-btn"
                        class="btn inline-flex justify-center btn-dark"><?php echo e(__('dashboard.submit')); ?></button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        function store() {
            let formData = new FormData();
            formData.append('name', document.getElementById('name').value);
            formData.append('email', document.getElementById('email').value);
            formData.append('phone', document.getElementById('phone').value);
            formData.append('image', document.getElementById('image').files[0]);
            formData.append('password', document.getElementById('password').value);
            axios.post('<?php echo e(route('admin.store')); ?>', formData).then(function(response) {
                toastr.success(response.data.message);
                document.getElementById('form').reset();
            }).catch(function(error) {
                toastr.error(error.response.data.message);

            });
        }
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\cyberAhmed\Desktop\karim alsayed\resources\views/pages/admin/create.blade.php ENDPATH**/ ?>