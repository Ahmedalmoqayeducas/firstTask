<?php $__env->startSection('content'); ?>

    <div class="card card-primary">
        <div class="card-header">
            <h3 class="card-title"><?php echo e(__('admin.create')); ?></h3>
        </div>
        <!-- /.card-header -->
        <!-- form start -->

        <form method="POST" action="<?php echo e(route('Roles.store')); ?>">
            
            <?php echo csrf_field(); ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger alert-dismissible  card">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>

                    <h5><i class="icon fas fa-ban"></i> Alert!</h5>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <?php echo e($error); ?>

                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>
                </div>
            <?php endif; ?>
            <?php if(session('message')): ?>
                <div class="alert alert-<?php echo e(session('alert')); ?> alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <h5><i class="icon fas fa-check"></i> Alert!</h5>
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>

            <div class="card-body">
                <div class="form-group mb-3">

                    <div class="form-group">
                        <label>Role</label>
                        <select class="form-control" id="guard_name" name="guard_name">
                            <option value="admin">Admin</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label>name</label>
                    <input id="name" name="name" value="<?php echo e(old('name')); ?>" type="text" class="form-control"
                        placeholder="Enter name">
                </div>


            </div>
            <!-- /.card-body -->

            <div class="card-footer">
                
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </form>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        function store() {
            axios.post('<?php echo e(route('Roles.store')); ?>', {
                    name: document.getElementById('name').value,
                    guard_name: document.getElementById('guard_name').value,

                }).then(function(response) {
                    console.log(response);

                    toastr.success(response.data.message);
                    document.getElementById('form').reset();
                })
                .catch(function(error) {
                    console.log(error);
                    toastr.error(error.response.data.message);
                });
        }
    </script>
    
    <script>
        $(function() {
            bsCustomFileInput.init();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\karim-alsayed\resources\views/pages/roles/create.blade.php ENDPATH**/ ?>