<?php $__env->startSection('content'); ?>

<?php echo $__env->make('components.news.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('components.news.news',[
'card'=>'col-lg-4',
'color'=>'white',
'title'=>'last news',
'news'=>$resent
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>





<?php echo $__env->make('components.news.news',[
'card'=>'col-lg-4',
'color'=>'gray',
'title'=>'local news',
'news'=> $local,
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('components.news.news',[
'card'=>'col-lg-3',
'color'=>'white',
'title'=>'sport news',
'news'=> $sport ,
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('components.news.news',[
'card'=>'col-lg-4',
'color'=>'gray',
'title'=>'international news',
'news'=>$international,
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<?php echo $__env->make('components.news.trend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\cyberAhmed\Desktop\Admin\resources\views/pages/first.blade.php ENDPATH**/ ?>