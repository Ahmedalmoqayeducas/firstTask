<section class="features">
    <div class="container">

        <div class="section-title">
            <h2>Features</h2>
            <p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit
                sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias
                ea. Quia fugiat sit in iste officiis commodi quidem hic quas.</p>
        </div>

        <div class="row" data-aos="fade-up">
            <div class="col-md-5">
                <img src="<?php echo e(asset('org/img/features-1.svg')); ?>" class="img-fluid" alt="">
            </div>
            <div class="col-md-7 pt-4">
                <h3>Voluptatem dignissimos provident quasi corporis voluptates sit assumenda.</h3>
                <p class="font-italic">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                    labore et dolore
                    magna aliqua.
                </p>
                <ul>
                    <li><i class="icofont-check"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat.
                    </li>
                    <li><i class="icofont-check"></i> Duis aute irure dolor in reprehenderit in voluptate velit.
                    </li>
                </ul>
            </div>
        </div>

        <div class="row" data-aos="fade-up">
            <div class="col-md-5 order-1 order-md-2">
                <img src="<?php echo e(asset('org/img/features-2.svg')); ?>" class="img-fluid" alt="">
            </div>
            <div class="col-md-7 pt-5 order-2 order-md-1">
                <h3>Corporis temporibus maiores provident</h3>
                <p class="font-italic">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                    labore et dolore
                    magna aliqua.
                </p>
                <p>
                    Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in
                    reprehenderit in voluptate
                    velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                    proident, sunt in
                    culpa qui officia deserunt mollit anim id est laborum
                </p>
            </div>
        </div>

        <div class="row" data-aos="fade-up">
            <div class="col-md-5">
                <img src="<?php echo e(asset('org/img/features-3.svg')); ?>" class="img-fluid" alt="">
            </div>
            <div class="col-md-7 pt-5">
                <h3>Sunt consequatur ad ut est nulla consectetur reiciendis animi voluptas</h3>
                <p>Cupiditate placeat cupiditate placeat est ipsam culpa. Delectus quia minima quod. Sunt saepe
                    odit aut quia voluptatem hic voluptas dolor doloremque.</p>
                <ul>
                    <li><i class="icofont-check"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat.
                    </li>
                    <li><i class="icofont-check"></i> Duis aute irure dolor in reprehenderit in voluptate velit.
                    </li>
                    <li><i class="icofont-check"></i> Facilis ut et voluptatem aperiam. Autem soluta ad fugiat.
                    </li>
                </ul>
            </div>
        </div>

        <div class="row" data-aos="fade-up">
            <div class="col-md-5 order-1 order-md-2">
                <img src="<?php echo e(asset('org/img/features-4.svg')); ?>" class="img-fluid" alt="">
            </div>
            <div class="col-md-7 pt-5 order-2 order-md-1">
                <h3>Quas et necessitatibus eaque impedit ipsum animi consequatur incidunt in</h3>
                <p class="font-italic">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                    labore et dolore
                    magna aliqua.
                </p>
                <p>
                    Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in
                    reprehenderit in voluptate
                    velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                    proident, sunt in
                    culpa qui officia deserunt mollit anim id est laborum
                </p>
            </div>
        </div>

    </div>
</section>
<?php /**PATH C:\Users\cyberAhmed\Desktop\karim alsayed\resources\views/components/org/features.blade.php ENDPATH**/ ?>