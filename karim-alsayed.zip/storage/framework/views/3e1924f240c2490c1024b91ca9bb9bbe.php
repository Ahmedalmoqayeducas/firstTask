<?php $__env->startSection('form'); ?>
    <div class="text-center 2xl:mb-10 mb-4">
        <h4 class="font-medium"><?php echo e(__('auth.recover')); ?></h4>
        <div class="text-slate-500 text-base">
            <?php echo e(__('auth.recover_title')); ?>

        </div>
    </div>
    <!-- BEGIN: Login Form -->
    <form class="space-y-4">
        <div class="fromGroup">
            <label class="block capitalize form-label  "><?php echo e(__('dashboard.password')); ?></label>
            <div class="relative "><input type="password" name="password" id="password" class=" form-control py-2   "
                    placeholder="<?php echo e(__('auth.password_ctr')); ?>" >
            </div>
        </div>
        <div class="fromGroup">
            <label class="block capitalize form-label  "><?php echo e(__('auth.confirm')); ?></label>
            <div class="relative "><input type="password" name="password" id="password_confirmation"
                    class="  form-control py-2   " placeholder="<?php echo e(__('auth.password_ctr')); ?>" >
            </div>
        </div>

        <button onclick="resetPassword()" type="button" class="btn btn-dark block w-full text-center"><?php echo e(__('auth.change_submit')); ?></button>
    </form>
    <!-- END: Login Form -->
    <div class="relative border-b-[#9AA2AF] border-opacity-[16%] border-b pt-6">
        <div
            class="absolute inline-block bg-white dark:bg-slate-800 dark:text-slate-400 left-1/2 top-1/2 transform -translate-x-1/2
                                    px-4 min-w-max text-sm text-slate-500 font-normal">

        </div>
    </div>
    <div class="max-w-[242px] mx-auto mt-8 w-full">

        <!-- BEGIN: Social Log in Area -->

        <!-- END: Social Log In Area -->
    </div>
    <div class="md:max-w-[345px] mx-auto font-normal text-slate-500 dark:text-slate-400 mt-12 uppercase text-sm">
        Back to
        <a href="<?php echo e(route('auth.show-login', ['guard' => session('guard')])); ?>"
            class="text-slate-900 dark:text-white font-medium hover:underline">
            Sign in Page
        </a>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        function resetPassword() {
            axios.post('<?php echo e(route('password.recover')); ?>', {
                email: `<?php echo e($email); ?>`,
                password: document.getElementById('password').value,
                password_confirmation: document.getElementById('password_confirmation').value,
                token: `<?php echo e($token); ?>`,

            }).then(function(response) {

                toastr.success(response.data.message);
                window.location.href = '/auth/<?php echo e(session('guard')); ?>/login';
            }).catch(function(error) {

                toastr.error(error.response.data.message);
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\cyberAhmed\Desktop\Admin\resources\views/pages/Auth/recover-password.blade.php ENDPATH**/ ?>