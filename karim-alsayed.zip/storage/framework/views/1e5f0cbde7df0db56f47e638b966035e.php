   <!-- Navigation -->
   <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(route('news.parent')); ?>">news</a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse"
            data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false"
            aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('news.parent')); ?>">home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('thread.local')); ?>">local news</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('thread.international')); ?>">International news</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('thread.sport')); ?>">sport news</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('news.conatct')); ?>">Contact</a>
                </li>

            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\Users\cyberAhmed\Desktop\Admin\resources\views/components/news/nav.blade.php ENDPATH**/ ?>