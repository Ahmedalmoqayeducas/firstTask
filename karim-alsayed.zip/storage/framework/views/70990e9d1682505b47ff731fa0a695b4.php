<section id="hero" class="d-flex justify-cntent-center align-items-center">
    <div id="heroCarousel" class="container carousel carousel-fade" data-ride="carousel">

        <!-- Slide 1 -->
        <div class="carousel-item active">
            <div class="carousel-container">
                <h2 class="animated fadeInDown">making your business <br>profitable for today and tomorrow</h2>
                <p class="animated fadeInUp"><h3 class="text-white">Inspiring customers & supporting through experience</h3></p>
                <div>
                    <a href="" class="btn-danger btn-get-started animated fadeInUp">Our Projects</a>
                    <a href="" class="btn-white  btn-get-started animated fadeInUp">Learn More</a>
                </div>
            </div>
        </div>



    </div>
</section>
<?php /**PATH D:\karim-alsayed\resources\views/components/org/slide.blade.php ENDPATH**/ ?>