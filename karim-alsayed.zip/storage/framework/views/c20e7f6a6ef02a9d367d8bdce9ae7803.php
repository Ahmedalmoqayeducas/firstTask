<?php $__env->startSection('content'); ?>
 <!-- Page Content -->
 <div class="container">

    <!-- Page Heading/Breadcrumbs -->
    <h1 class="mt-4 mb-3"><?php echo e($type); ?> news

    </h1>

    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="index.html">Home</a>
      </li>
      <li class="breadcrumb-item active"><?php echo e($type); ?></li>
    </ol>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


    <!-- news title One -->
    <div class="row">
      <div class="col-md-7">
        
        <a href="<?php echo e(route('thread.details',$element['id'])); ?>">

          <img class="img-fluid full-width h-200 rounded mb-3 mb-md-0" src="img/1.jpg" alt="">
        </a>
      </div>
      <div class="col-md-5">
        <h3><?php echo e($element['title']); ?></h3>
        <p><?php echo e($element['description']); ?></p>
        <a class="btn btn-primary" href="<?php echo e(route('thread.details',$element['id'])); ?>">View news title
          <span class="glyphicon glyphicon-chevron-right"></span>
        </a>
      </div>
    </div>
    <!-- /.row -->

    <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php echo e($data->links()); ?>

  </div>
  <!-- /.container -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\cyberAhmed\Desktop\Admin\resources\views/pages/thread.blade.php ENDPATH**/ ?>