<header id="header" class=" fixed-top  header-transparent  ">
    <div class="container">

        <div class="logo float-left">
            <h1 class="text-white "><a href="<?php echo e(route('home')); ?>"><img
                        src="
              <?php if(Route::currentRouteName() == 'home'): ?> <?php echo e(asset('org/img/logo-avada-business-02.png')); ?>

              <?php else: ?> <?php echo e(asset('org/img/logo-avada-business-01.png')); ?> <?php endif; ?>
                "></a>
            </h1>
            <!-- Uncomment below if you prefer to use an image logo -->
            <!-- <a href="index.html"><img src="img/logo.png" alt="" class="img-fluid"></a>-->
        </div>

        <nav class="nav-menu float-right d-none d-lg-block">
            <ul>
                <li class=" <?php if(Route::currentRouteName() == 'home'): ?> active <?php endif; ?>"><a
                        class="  <?php if(Route::currentRouteName() == 'home'): ?> text-light <?php else: ?> text-dark <?php endif; ?>

                        "
                        href="<?php echo e(route('home')); ?>">
                        <h5>

                            Home
                        </h5>
                    </a>
                </li>
                <li class="<?php if(Route::currentRouteName() == 'activities'): ?> active <?php endif; ?>"><a
                        class="<?php if(Route::currentRouteName() == 'home'): ?> text-light
                                <?php elseif(Route::currentRouteName() == 'activities'): ?> text-danger
                                <?php else: ?> text-dark <?php endif; ?>"
                        href="<?php echo e(route('activities')); ?>">
                        <h5>

                            Activities
                        </h5>
                    </a></li>
                <li class="<?php if(Route::currentRouteName() == 'team'): ?> active <?php endif; ?>"><a
                        class="<?php if(Route::currentRouteName() == 'home'): ?> text-light
                    <?php elseif(Route::currentRouteName() == 'team'): ?> text-danger
                    <?php else: ?> text-dark <?php endif; ?>"
                        href="<?php echo e(route('team')); ?>">
                        <h5>

                            Team
                        </h5>
                    </a></li>
                
                <li class="<?php if(Route::currentRouteName() == 'about'): ?> active <?php endif; ?>"><a
                        class="<?php if(Route::currentRouteName() == 'home'): ?> text-light
                    <?php elseif(Route::currentRouteName() == 'about'): ?> text-danger
                    <?php else: ?> text-dark <?php endif; ?>"
                        href="<?php echo e(route('about')); ?>">
                        <h5>

                            About Us
                        </h5>
                       </a>
                </li>


                <li class="pl-5 <?php if(Route::currentRouteName() == 'contact'): ?> active <?php endif; ?>"><a
                        class="<?php if(Route::currentRouteName() == 'home'): ?> text-light
                                <?php elseif(Route::currentRouteName() == 'contact'): ?> text-danger
                                <?php else: ?> text-dark <?php endif; ?>"
                        href="<?php echo e(route('contact')); ?>">
                        <h5>

                            Contact Us
                        </h5>
                         </a>
                </li>
            </ul>
        </nav><!-- .nav-menu -->

    </div>
</header>
<?php /**PATH C:\Users\cyberAhmed\Desktop\laravel\karim-alsayed\resources\views/components/org/header.blade.php ENDPATH**/ ?>