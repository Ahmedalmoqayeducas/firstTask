
<?php $__env->startSection('start'); ?>
element information
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
<div class="card">
    <div class="card-header">
      
      <h2 class="card-title">Post info</h2>

      <div class="card-tools">
        <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
          <i class="fas fa-minus"></i>
        </button>
      
      </div>
    </div>
    <a3 class="card-body">
      Title:<?php echo e($post['title']); ?>

    </a3>
    <!-- /.card-body -->
    <div class="card-footer">
      description : <?php echo e($post->description); ?>

    </div>
    <!-- /.card-footer-->

  </div>
  <div class="card mt-4">
    <div class="card-header">
      Post Creator Info
    </div>
    <div class="card-body">
      <h5 class="card-title">Name : <?php echo e($post->user->name); ?></h5>
      <p class="card-text">email:<?php echo e($post->user->email); ?></p>
      <p class="card-text">Created At :<?php echo e($post->user->created_at); ?></p>
    </div>
  </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.layouts.parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MgAd\Desktop\php-2024\Admin\resources\views/cms/pages/show.blade.php ENDPATH**/ ?>