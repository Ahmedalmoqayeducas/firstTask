<?php $__env->startSection('content'); ?>
    <div class="card-body px-6 pb-6">
        <div class="overflow-x-auto -mx-6">
            <div class="inline-block min-w-full align-middle">
                <div class="overflow-hidden ">
                    <table class="min-w-full divide-y divide-slate-100 table-fixed dark:divide-slate-700">
                        <thead class="bg-slate-200 dark:bg-slate-700">
                            <tr>

                                <th scope="col" class=" table-th ">
                                    id
                                </th>

                                <th scope="col" class=" table-th ">
                                    Permission Name
                                </th>

                                <th scope="col" class=" table-th ">
                                    guard name
                                </th>
                                <th scope="col" class=" table-th ">
                                    Selecting
                                </th>

                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-slate-100 dark:bg-slate-800 dark:divide-slate-700">
                            <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr id="role_<?php echo e($ticket->id); ?>">
                                    <td class="table-td"><?php echo e($loop->index + 1); ?></td>
                                    <td class="table-td"><?php echo e($ticket->name); ?></td>
                                    <td class="table-td"><?php echo e($ticket->guard_name); ?></td>
                                    <td class="table-td">
                                        <div class="flex space-x-3 rtl:space-x-reverse">
                                            
                                            <input type="checkbox" id="permission_<?php echo e($ticket->id); ?>"
                                                onclick="updatePermission('<?php echo e($ticket->id); ?>')"
                                                <?php if($ticket->assigned): echo 'checked'; endif; ?>>
                                            <label for="permission_<?php echo e($ticket->id); ?>">
                                            </label>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
                <div class="container">
                    
                </div>
                <!-- /.card-body -->
            </div>
        </div>
    </div>
    <script>
        function updatePermission(id) {
            axios.put('/dash/role/<?php echo e($role->id); ?>/permissions', {
                permission_id: id
            }
            ).then(function(response) {
                toastr.success(response.data.message);
            }).catch(function(error) {

                toastr.error(error.response.data.message || "حدث خطأ.");
            });
        }
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('dashboard/toastr/toastr.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/toastr/toastr.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\karim-alsayed\resources\views/pages/roles/role-permissions.blade.php ENDPATH**/ ?>