<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>news</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('news/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php echo e(asset('news/css/modern-business.css')); ?>" rel="stylesheet">

</head>

<body>
    
    <?php echo $__env->make('components.news.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    



    <!-- Page Content -->
    <?php echo $__env->yieldContent('content'); ?>
    <!-- Footer -->

    <?php echo $__env->make('components.news.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- scripts -->
    <script src="<?php echo e(asset('news/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('news/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

</body>

</html>
<?php /**PATH C:\Users\cyberAhmed\Desktop\Admin\resources\views/layouts/parent.blade.php ENDPATH**/ ?>