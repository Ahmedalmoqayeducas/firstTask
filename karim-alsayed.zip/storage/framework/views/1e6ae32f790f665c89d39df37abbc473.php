<li class="">
    <a href="#" class="navItem">
        <span class="flex items-center">
            <iconify-icon class=" nav-icon" icon="<?php echo e($icon); ?>"></iconify-icon>
            <span><?php echo e($list_name); ?></span>
        </span>
        <iconify-icon class="icon-arrow" icon="heroicons-outline:chevron-right"></iconify-icon>
    </a>
    <ul class="sidebar-submenu">
        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <li>
                <a href="<?php echo e(route($element['route'])); ?>"
                    class="<?php if(Route::currentRouteName() == $element['route']): ?> active <?php endif; ?>"><?php echo e($element['name']); ?></a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</li>
<?php /**PATH C:\Users\cyberAhmed\Desktop\karim alsayed\resources\views/components/dashboard/sidebar/sidbard-lists.blade.php ENDPATH**/ ?>