<?php $__env->startSection('content'); ?>
    <!-- ======= Services Section ======= -->
    <?php echo $__env->make('components.org.activities', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Services Section -->

    <!-- ======= video and text Section ======= -->
    <?php echo $__env->make('components.org.video', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End video and text Section -->

    <!-- ======= Features Section ======= -->
    <?php echo $__env->make('components.org.features', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Features Section -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('slide'); ?>
    <?php echo $__env->make('components.org.slide', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.org', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\karim-alsayed\resources\views/pages/org/home.blade.php ENDPATH**/ ?>