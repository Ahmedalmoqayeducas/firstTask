<!-- BEGIN: Sidebar -->
<div class="sidebar-wrapper group">
    <div id="bodyOverlay" class="w-screen h-screen fixed top-0 bg-slate-900 bg-opacity-50 backdrop-blur-sm z-10 hidden">
    </div>
    <div class="logo-segment">
        <a class="flex items-center" href="index.html">
            <img src="<?php echo e(asset('dashboard/images/logo/logo-c.svg')); ?>" class="black_logo white_logo" alt="logo">

            <span class="ltr:ml-3 rtl:mr-3 text-xl font-Inter font-bold text-slate-900 dark:text-white">
               LIORA

            </span>
        </a>
        <!-- Sidebar Type Button -->
        <div id="sidebar_type" class="cursor-pointer text-slate-900 dark:text-white text-lg">
            <iconify-icon class="sidebarDotIcon extend-icon text-slate-900 dark:text-slate-200"
                icon="fa-regular:dot-circle"></iconify-icon>
            <iconify-icon class="sidebarDotIcon collapsed-icon text-slate-900 dark:text-slate-200"
                icon="material-symbols:circle-outline"></iconify-icon>
        </div>
        <button class="sidebarCloseIcon text-2xl">
            <iconify-icon class="text-slate-900 dark:text-slate-200" icon="clarity:window-close-line">
            </iconify-icon>
        </button>
    </div>
    <div id="nav_shadow"
        class="nav_shadow h-[60px] absolute top-[80px] nav-shadow z-[1] w-full transition-all duration-200 pointer-events-none opacity-0">
    </div>
    <div class="sidebar-menus bg-white dark:bg-slate-800 py-2 px-4 h-[calc(100%-80px)] overflow-y-auto z-50"
        id="sidebar_menus">
        <ul class="sidebar-menu">
            <li class="sidebar-menu-title">
                <?php echo e(__('dashboard.dashboard')); ?></li>
            <li class="">
                <a href="<?php echo e(route('dashboard')); ?>" class="navItem <?php if(str_contains(Route::currentRouteName(), 'dashboard')): ?> active <?php endif; ?>">
                    <span class="flex items-center">
                        <iconify-icon class=" nav-icon" icon="heroicons-outline:home"></iconify-icon>
                        <span><?php echo e(__('dashboard.home')); ?></span>
                    </span>

                </a>
            </li>
            <?php echo $__env->make('components.dashboard.sidebar.sidbard-lists', [
                'list_name' => __('dashboard.admin'),
                'icon' => 'heroicons-outline:home',
                'elements' => [
                    [
                        'name' => __('dashboard.create'),
                        'route_name' => 'admin.create',
                        'route' => 'admin.create',
                    ],
                    [
                        'name' => __('dashboard.read'),
                        'route_name' => 'admin.index',
                        'route' => 'admin.index',
                    ],
                    [
                        'name' => __('dashboard.trash'),
                        'route_name' => 'admin.trash',
                        'route' => 'admin.trash',
                    ],
                ],
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.dashboard.sidebar.sidbard-lists', [
                'list_name' => 'Team Managment',
                'icon' => 'heroicons-outline:home',
                'elements' => [
                    [
                        'name' => __('dashboard.create'),
                        'route_name' => 'team.create',
                        'route' => 'team.create',
                    ],
                    [
                        'name' => __('dashboard.read'),
                        'route_name' => 'index',
                        'route' => 'team.index',
                    ],
                    [
                        'name' => __('dashboard.trash'),
                        'route_name' => 'trash',
                        'route' => 'team.trash',
                    ],
                ],
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.dashboard.sidebar.sidbard-lists', [
                'list_name' =>'Posts Managment',
                'icon' => 'heroicons-outline:home',
                'elements' => [
                    [
                        'name' => __('dashboard.create'),
                        'route_name' => 'create',
                        'route' => 'posts.create',
                    ],
                    [
                        'name' => __('dashboard.read'),
                        'route_name' => 'index',
                        'route' => 'posts.index',
                    ],
                    [
                        'name' => __('dashboard.trash'),
                        'route_name' => 'trash',
                        'route' => 'posts.trash',
                    ],
                ],
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php echo $__env->make('components.dashboard.sidebar.sidbard-lists', [
                'list_name' => __('dashboard.account'),
                'icon' => 'heroicons-outline:user',
                'elements' => [
                    [
                        'name' => __('dashboard.change_password'),
                        'route_name' => 'change',
                        'route' => 'password.change',
                    ],
                ],
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        </ul>
    </div>
</div>
<!-- End: Sidebar -->
<?php /**PATH C:\Users\cyberAhmed\Desktop\laravel\karim-alsayed\resources\views/components/dashboard/sidebar.blade.php ENDPATH**/ ?>