<?php $__env->startSection('content'); ?>
    <div class="card p-6">
        <div class="grid xl:grid-cols-4 lg:grid-cols-2 md:grid-cols-2 grid-cols-1 gap-5 place-content-center">
            <div class="flex space-x-4 h-full items-center rtl:space-x-reverse">
                <div class="flex-none">
                    <div class="h-20 w-20 rounded-full">
                        <img src="<?php echo e(Storage::url("$user->image")); ?>" alt="" class="w-full h-full">
                    </div>
                </div>
                <div class="flex-1">
                    <h4 class="text-xl font-medium mb-2">
                        <span class="block font-light">
                            <?php echo e(__('dashboard.good_evning')); ?>

                        </span>
                        <span class="block"> <?php echo e($user->name); ?></span>
                    </h4>
                    <p class="text-sm dark:text-slate-300"><?php echo e(__('dashboard.welcom')); ?>

                    </p>

                </div>
            </div>

            <!-- BEGIN: Group Chart3 -->




            <!-- END: Group Chart3 -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\cyberAhmed\Desktop\karim alsayed\resources\views/pages/admin/dashboard.blade.php ENDPATH**/ ?>