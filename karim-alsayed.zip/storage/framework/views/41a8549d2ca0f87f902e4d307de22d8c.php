<footer class="md:block hidden" id="footer">
    <div
        class="site-footer px-6 bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-300 py-4 ltr:ml-[248px] rtl:mr-[248px]">
        <div class="grid md:grid-cols-2 grid-cols-1 md:gap-5">
            <div class="text-center ltr:md:text-start rtl:md:text-right text-sm">
                COPYRIGHT ©
                <span id="thisYear"></span>
                <?php echo e(__('dashboard.copyright')); ?>

                
            </div>
            <div class="ltr:md:text-right rtl:md:text-end text-center text-sm">
               
                <?php echo e(__('dashboard.edited_By')); ?>

                <a href="" target="_blank" class="text-primary-500 font-semibold">
                    AH-Moqayed
                </a>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\Users\cyberAhmed\Desktop\laravel\karim alsayed\resources\views/components/dashboard/footer.blade.php ENDPATH**/ ?>