
<?php $__env->startSection('start'); ?>
    Edit Informations
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <form method="POST" action="<?php echo e(route('posts.update',$post->id)); ?>">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PUT'); ?>
        <div class="card col-md-12">
            <div class="card-body">
                <div class="form-group">
                    <label>Title</label>
                    <input name="title" type="text" class="form-control"  value="<?php echo e($post->title); ?>">
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" class="form-control" rows="3" placeholder="Enter Description"><?php echo e($post->description); ?></textarea>
                </div>
                <div class="form-group">

                    <div class="form-group">
                        <label>Post Creator</label>
                        <select name ="user_id"class="form-control select2 select2-hidden-accessible" style="width: 100%;"
                        tabindex="-1" aria-hidden="true">
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php if($user->id==$post->user->id): ?> <?php if(true): echo 'selected'; endif; ?>
                            
                        <?php endif; ?> value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

            </div>
            <!-- /.card-body -->

            <div class="card-footer">
                <button type="submit" class="btn btn-success">Update</button>
            </div>
    </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.layouts.parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MgAd\Desktop\php-2024\Admin\resources\views/cms/components/edit.blade.php ENDPATH**/ ?>