<?php $__env->startSection('content'); ?>

<div class="card card-primary">
    <div class="card-header">
        <h3 class="card-title"><?php echo e(__('admin.updated_at')); ?></h3>
    </div>
    <!-- /.card-header -->
    <!-- form start -->

    
        <form id="form">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="card-body">
                <div class="form-group mb-3">

                    <div class="form-group">
                        <label>user</label>
                        <select class="form-control" id="guard_name" name="guard_name">

                            <option value="admin" <?php if($role->guard_name='admin'): echo 'checked'; endif; ?>>Admin</option>
                            <option value="user"<?php if($role->guard_name='user'): echo 'checked'; endif; ?>>User</option>

                        </select>
                    </div>
                </div>
                <div class="form-group mb-3">


                    <div class="form-group">
                        <label>name</label>
                        <input id="name" name="name" value="<?php echo e($role->name); ?>" type="text" class="form-control"
                            placeholder="Enter name">
                    </div>


                </div>

            </div>
            <!-- /.card-body -->

            <div class="card-footer">
                <button type="button" onclick="update(<?php echo e($role->id); ?>)" class="btn btn-primary">Submit</button>
            </div>
        </form>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    function update(id) {

            axios.put(`/dashboard/role/${id}`, {
                name: document.getElementById('name').value,
                guard_name: document.getElementById('guard_name').value,
            }).then(function(response) {
                toastr.success(response.data.message);
                window.location.href = '<?php echo e(route('role.index')); ?>';
            }).catch(function(error) {
                toastr.error(error.response.data.message);
            });
        }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\karim-alsayed\resources\views/pages/roles/edit.blade.php ENDPATH**/ ?>